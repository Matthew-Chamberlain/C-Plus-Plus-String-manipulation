//**********************************************************************************************
//4COM1037 – C++ String Manipulation Challenge
//Student ID: 17038003
//This program including all the code is my own work and has been tested fully before submission
// *********************************************************************************************

#include <iostream> // includes the library that allows input and output
#include <string> // includes the library that allows string types and conventions including begin & end iterator
#include <algorithm> // includes the library that contains a number of inbuilt functions used for sorting, randomising and reversing and more

using namespace std; //tell the compiler that by default to use the “std” – this means that we don’t need to keep saying “std::cout” we can just use: “cout”

// this function is used to acquire input from the user, it expects no value and returns the string the user enters
string GetWord(void){
  string localString; // defines a string variable called localString
  cout << "Please enter a new word or phrase: "; // prompts the user to enter a word by outputing it.
  getline(cin >> ws, localString); // takes the input of the user and stores it in the localString variable, ws allows spaces to be stored in the string.
  cout << endl; // creates a line break by ending the line
  return localString; // returns localString to the function where GetWord() was called from
}

// this function is used to reverse the word that the user entered. It accepts a string variable which is the users word and returns the reversed word.
string ReverseWord(string originalString){
  string localString = originalString; // defines a string variable localString and assigns it hte value of orginalString
  reverse(localString.begin(), localString.end()); // calls the inbuilt reverse function, the reverse function needs to know the begining and end of the string it's reversing
  return localString; // returns local string to the function that called the ReverseWord() function
}
// this string is used to convert every letter in the string to uppercase. it takes in a string variable, which is the users word and returns the uppercase word.
string ToUpper(string originalString){
  string localString = originalString; // defines a string variable called localString and assigns it the value of orginalString
  // for loop that loops as many times as there are characters in the string
  for(int i = 0; i < localString.length(); i++){
    localString[i] = toupper(localString[i]); // for every character in the string the inbuilt toupper function is called converting it to uppercase
  }
  return localString; // returns the uppercase word stored in localString
}
// this string is used to convert every letter in the string to lowercase. it takes in a string variable, which is the users word and returns the lowercase word.
string ToLower(string originalString){
  string localString = originalString; // defines a string variable called localString and assigns it the value of orginalString
  // for loop that loops as many times as there are characters in the string
  for(int i = 0; i < localString.length(); i++){
    localString[i] = tolower(localString[i]); // for every character in the string the inbuilt tolower function is called converting the character to lowercase
  }
  return localString; // returns the lowercase word stored in localString 
}
//this function is used to randomise the characters of a string. It expects a string to be parsed which is the word the user enters and returns the radomised word
string RandomiseWord(string originalString){
  string localString = originalString; // defines a string variable localString and assigns it the value of originalString
  random_shuffle(localString.begin(), localString.end()); // calls the inbuilt random_shuffle function to randomise the position of characters in the string. The function needs to know where the string begins and ends.
  return localString; // returns the randomised word stored in localString
}
// this function is used to sort a word into alphabetical order. The function expects a string variable, which is the users word, and returns a string that contains the sorted word
string OrderWord(string originalString){
  string localString = originalString; // defines a string variable called localString and assigns it the value of originalString
  localString = ToLower(localString); // calls the ToLower function parsing localstring because the inbuilt sort function always puts uppercase letters before lowercase letters, regardless of the characters so the string needs to be fully lowercase.
  sort(localString.begin(), localString.end()); // calls the inbuilt sort function to put the users word on alphabetical order. The function needs to know the beginning and end of the string
  return localString; // retruns the sorted word stored in localString
}
// this function is used to allow the user to quit the program. it expects and returns no values
void QuitNow(void){
  string localString; // defines a string called localString
  cout << "Are you sure (Y/N)? "; // prompts the user to input a value after asking them whether they want to quit
  cin >> localString; // takes the input from the user and stores it in the variable localString
  cout << endl; // creates a line break
  if(localString == "Y" || localString == "y" || localString == "Yes"){ // if the user enters Y, y or Yes then the indented code is run
    exit(EXIT_SUCCESS); // code that stops the execution of the program,
  }  
}
// this function is used to display the menu of the program and allows the user to manipulate a string by inputting different menu options
void Menu(void){
  string currentString = "17038003"; // defines a string variable called currentString and assigns it the value of my student ID
  string modifiedString = "nothing"; // defines a string variable called modifiedString and assigns it the valeu of "nothing"
  string input; // defines a string vairiable called input
  int menuOption; // defines an integer variable called menuOptrion
  
  // do while loop that displays the mneu at least once and loops in certain conditions are met.
  do{
    // a series of couts that are used to dispay the menu which informs the user of the functionality of the program and which number each option is. /n and endl are used to insert a new line and /t is used to indent the text.
    cout << "C++ String Manipulation Challenge" << endl << endl; 
    cout << "\t1. Enter a word or phrase (current word/phrase is: " << currentString << ")." << endl; // this line also outputs the value of the currentString variable
		cout << "\t2. Reverse the current word." << endl;
    cout << "\t3. Convert the current word to uppercase." << endl;
    cout << "\t4. Convert the current word to lowercase." << endl;
    cout << "\t5. Randomise the letters in the current word." << endl;
    cout << "\t6. Sort the letters in the current word in ascending alphabetical order." << endl;
		cout << "\t0. Quit the program." << endl;

    cout << "\n\tThe last word/phrase returned was: " << modifiedString << endl; // this line also outputs the value of the modifiedString variable
    cout << "\nPlease enter a valid option (1 - 6 or 0 to quit): "; // prompts the user to enter a value for the menu option
    
    getline(cin >> ws, input); // the getline function gets the input of the user and stores it in the input variable, ws is used so that spaces can be included.
    cout << endl; // creates a line break
    menuOption = atoi(input.c_str()); // converts the value of input variable to an integer and stores it in the menuOption variable, if the input variable is not a digit menuOption will be set to 0
    if(isdigit(input[0]) == false || input.length() != 1){ // if statement used to ensure that the only inputs that are accepted are 1 character inputs where the character is a digit
      menuOption = -1; // sets the menuOption variable to -1, an value that the program will never accept as if the character is not a digit then the string to int conversion will return 0, this is the quit option so menuoption needs to be updated.
    }
    if(menuOption < 0 || menuOption > 6){ // if menuOption is less than 0 or greater than 6 run the indented code
      cout << "Unfortunately, \'" << input <<"\' is not a valid option, please try again. \n\n"; // prints out an message tellign the user that their input was invalid
    }
    // switch statement that runs the code for a certain case depending on the value of the menuOption variable
    switch(menuOption){
      case 1: // run the code if menuOption is equal to 1
          currentString = GetWord(); // calls the GetWord function and stores the returned result in the currentString variable
          break; // used to exit the switch statment 

      case 2: // runs the code if menuOption is equal to 2
          modifiedString = ReverseWord(currentString);// calls the ReverseWord function parsing the variable currentString and storing the returned result in the modifiedString variable
          break; // used to exit the switch statement

      case 3: // runs the code if menuOption is equal to 3
          modifiedString = ToUpper(currentString); // calls the ToUpper function parsing the variable currentString and storing the returned result in the modifiedString variable
          break; // used to exit the switch statement
      
      case 4: // runs the code if menuOption is equal to 4
          modifiedString = ToLower(currentString); // calls the ToLower function parsing the variable currentString and storing the returned result in the modifiedString variable
          break; // used to exit the switch statement

      case 5: // runs the code if menuOption is equal to 5
          modifiedString = RandomiseWord(currentString); // calls the RandomiseWord function parsing the variable currentString and storing the returned result in the modifiedString variable
          break; // use dto exit the switch statement

      case 6: // runs the code if menuOption is equal to 6
        modifiedString = OrderWord(currentString); // calls the OrderWord function parsing the variable currentString and storing the returned result in the modifiedString variable
        break; // used to exit the switch statement 

      case 0: // runs the code if menuOption is equal to 0
        QuitNow(); // calls the QuitNow function
        break; // used to exit the switch statement
    }
    
  }while(true); // the do while loop will continue to loop while true is equal to true so it will always loop until the user quits using the QuitNow function. 
}
// the main function is the function that is first run when the program is run
int main() {
  Menu(); // calls the Menu function
}

/* Test Log
	*****************************************************************************************
	Test Date, Use & Operations, Description, What did you test, Results, Reflections			
	*****************************************************************************************
      5/3/19 Menu function - The menu was output with the same layout as the menu in the breif and the correct default values were loaded, studentID for currentString and "nothing for modifiedString". - Passed
      5/3/19 GetWord function - When the user entered 1 in the menu the GetWord function was called, the user could enter a word and the returned value was stored in the currentString variable and displayed in the menu. - Passed
      5/3/19 ReverseWord function - When the user entered 2 in the menu the ReverseWord function was called and reversed the word that the user entered. The reversed word was then returned and stored in the modifiedString variable and displayed in the menu. - Passed
      5/3/19 ToUpper function - When the user entered 3 in the menu the ToUpper function was called and made every letter of the string, the user entered, uppercase. The uppercase word was then returned and stored in the modifiedString variable and displayed in the menu. - Passed
      5/3/19 ToLower function - When the user entered 4 in the menu the ToLower function was called and made every letter of the users string lowercase. The lowercase string was then returned and stored in the modifiedString variable and displayed in the menu. - Passed
      5/3/19 RandomiseWord function - When the user entered 5 in the menu the RandomiseWord function was called that randomised the characters of the users string. The random string was then returned and stored in the modifiedString variable and displayed in the menu. - Passed
      5/3/19 OrderWord function - When the user entered 6 in the menu the OrderWord function was called and attempted to sort the users string in alphabetical order. After being sorted the word was returned and stored in the modifiedString variable and displayed in the menu. However the word was not sorted correctly as uppercase letters would always be put at the front of the sort regardless of wether it was in alphabetical order. for example "D" would always come before "a". To fix this issue I will add a call to the ToLower function in the OrderWord function to ensure there are no capital letters in the string so it can be sorted correctly. - Failed
      5/3/19 OrderWord function - After adding the call to the ToLower function in the OrderWord function the users word is always sorted correctly regardless of wether the user enters the word with capital letters or not. - Passed
      5/3/19 QuitNow function - When the user entered 0 in the menu the QuitNow function was called that asked the user if they actually wanted to quit. if the user entered one of the valid inputs defined in the brief, "Y, y or Yes", the program would quit, if any other input was entered the program would return to the menu function. - Passed
      5/3/19 Menu function - After the user has entered a menu option and the function is run the code would loop and the menu would be displayed again and the user can enter a new menu option. This happens endlessly until the user enters a valid option after calling the QuitNow function. - Passed
      5/3/19 Menu function - if the user enters a number that is outside of the range of valid menu option the program outputs the appropirate respone, e.g "Unfortunately, ‘8’ is not a valid option, please try again." - Passed
      5/3/19 Menu function - if the user enters an alphabet or special character for the menu option it would not output the correct respone, for example if the user entered "q" the program would output "Unfortunately, ‘0’ is not a valid option, please try again." in addition to this as the program sets the input to 0 the QuitNow function would be called. This happens because cin cannot put an alphabet or special character into an integer variable and if the input fails it sets the menuOption variable to 0. To fix this issue I could have the user enter the menu option as into a string variable which will be converted to an int. If the user enters an alphabet or special character the menuOption variable will be set to a value outside the range of valid inputs such as -1. In addition the string variable would be used in the error message instead of the menuOption variable - Failed
      9/3/19 - Menu function - When the user enters a menu option it is stored in a string variable and converted to an integer. if the character is not a digit or the user enters a word or phrase for the menu option the menu option would be set to -1, so that the input will never be accepted. Also the string variable is being used in the error message so that the users original input is displayed in the message, for example "Unfortunately, ‘q’ is not a valid option, please try again." instead of "Unfortunately, ‘-1’ is not a valid option, please try again." - Passed
*/